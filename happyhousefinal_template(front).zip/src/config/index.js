const API_BASE_URL = "http://localhost:9999/vue";
const APT_DEAL_URL =
  "http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTradeDev";
const MAP_URL =
  "//dapi.kakao.com/v2/maps/sdk.js?appkey=6331aee7aadedb9f97782a69e73678a9&libraries=services";

export { API_BASE_URL, APT_DEAL_URL, MAP_URL };
