<template>
  <div class="text-white">
    <h1>
      <b-icon icon="exclamation-square" font-scale="1"></b-icon>
      Third section!!<br /><br /><br />
      <h6>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,</p>
        <p>sed do eiusmodtempor incididunt ut labore et dolore magna aliqua.</p>
        <p>Ut enim ad minimveniam,</p>
        <p>quis nostrud exercitation ullamco laboris nisi ut</p>
        <p>aliquip ex eacommodo consequat.</p>
        <p>Duis aute irure dolor in reprehenderit in voluptate</p>
        <p>velit esse cillum dolore eu fugiat nulla pariatur.</p>
        <p>Excepteur sint occaecat cupidatat non proident,</p>
        <p>sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
      </h6>
    </h1>
  </div>
</template>

<script></script>

<style></style>
