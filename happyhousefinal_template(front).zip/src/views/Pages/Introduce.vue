<template>

<div id="app">
    <div class="header pb-8 pt-5 pt-lg-8 d-flex align-items-center profile-header"
        style="min-height: 600px; background-image: url(https://png.pngtree.com/illustrations/20190321/ourlarge/pngtree-programmer-cartoon-jobs-computer-png-image_33663.jpg); background-size: cover; background-position: center top;">
      <b-container fluid>
        <!-- Mask -->
        <span class="mask bg-gradient-primary opacity-8"></span>
        <!-- Header container -->
        <b-container fluid class="d-flex align-items-center">
          <b-row >
            <b-col lg="7" md="10">
              <h1 class="display-2 text-white">About Us</h1>
              <!-- <p class="text-white mt-0 mb-5">This is your profile page. You can see the progress you've made with your
                work and manage your projects or assigned tasks</p> -->
            </b-col>
          </b-row>
        </b-container>
      </b-container>
    </div>

    <b-container fluid class="mt--6">
      <b-row>
        <b-col xl="5" class="order-xl-2 mb-5">
          <b-card no-body class="card-profile" alt="Image placeholder" img-top>
    <b-row class="justify-content-center">
      <b-col lg="3" class="order-lg-2">
        <div class="card-profile-image">
          <a href="#">
            <b-img src="/assets/여자.PNG" rounded="circle" />
          </a>
        </div>
      </b-col>
    </b-row>

    <b-card-header class="text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">
      <div class="d-flex justify-content-between">
        <a href="#" class="btn btn-sm btn-info mr-4">Connect</a>
        <a href="#" class="btn btn-sm btn-default float-right">Message</a>
      </div>
    </b-card-header>
    <b-card-body class="pt-0">
      <div class="text-center">
        <div class="h3 font-weight-300">
          <br/><br/><br/>
          <i class="ni location_pin mr-2"></i>김은지
        </div>
        <div class="h3 mt-4">
          <i class="ni business_briefcase-24 mr-2"></i>이메일
        </div>
        <div><i class="ni education_hat mr-2"></i>desc</div>
        <hr class="my-4" />
        <p>
          Ryan — the name taken by Melbourne-raised, Brooklyn-based Nick Murphy
          — writes, performs and records all of his own music.
        </p>
        <a href="#">Go Top</a>
      </div>
    </b-card-body>
  </b-card>
        </b-col>
        <b-col xl="5" class="order-xl-1">
          <b-card no-body class="card-profile" alt="Image placeholder" img-top>
    <b-row class="justify-content-center">
      <b-col lg="3" class="order-lg-2">
        <div class="card-profile-image">
          <a href="#">
            <b-img src="/assets/남자.PNG" rounded="circle" />
          </a>
        </div>
      </b-col>
    </b-row>

    <b-card-header class="text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">
      <div class="d-flex justify-content-between">
        <a href="#" class="btn btn-sm btn-info mr-4">Connect</a>
        <a href="#" class="btn btn-sm btn-default float-right">Message</a>
      </div>
    </b-card-header>
    <b-card-body class="pt-0">
      <div class="text-center">
        <div class="h3 font-weight-300">
          <br/><br/><br/>
          <i class="ni location_pin mr-2"></i>정해윤
        </div>
        <div class="h3 mt-4">
          <i class="ni business_briefcase-24 mr-2"></i>이메일
        </div>
        <div><i class="ni education_hat mr-2"></i>desc</div>
        <hr class="my-4" />
        <p>
          Ryan — the name taken by Melbourne-raised, Brooklyn-based Nick Murphy
          — writes, performs and records all of his own music.
        </p>
        <a href="#">Go Top</a>
      </div>
    </b-card-body>
  </b-card>
        </b-col>
      </b-row>
    </b-container>
  </div>
  
</template>
<script>
 
</script>
<style>
</style>
