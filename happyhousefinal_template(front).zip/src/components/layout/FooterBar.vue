<template>
  <!-- Footer -->

  <div class="footer navbar-fixed-bottom">
    <footer class="text-center text-lg-start bg-dark text-muted">
      <!-- Section: Social media -->
      <section
        class="
          d-flex
          justify-content-center justify-content-lg-between
          p-4
          border-bottom
        "
      >
        <!-- Right -->
        <div class="container text-center text-md-start">
          <a href="https://github.com" class="me-4 text-reset">
            <b-icon icon="github" /> Github </a
          >&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="https://google.com" class="me-4 text-reset">
            <b-icon icon="google" />oogle </a
          >&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="https://ssafy.com" class="me-4 text-reset">
            <b-icon icon="info-circle" /> Ssafy </a
          >&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="https://facebook.com" class="me-4 text-reset">
            <b-icon icon="facebook" />acebook </a
          >&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="https://twitter.com" class="me-4 text-reset">
            <b-icon icon="twitter" /> Twitter </a
          >&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="https://isntagram.com" class="me-4 text-reset">
            <b-icon icon="camera-fill" /> Instagram </a
          >&nbsp;&nbsp;&nbsp;&nbsp;
        </div>
        <!-- Right -->
      </section>
      <!-- Section: Social media -->

      <!-- Section: Links  -->
      <section class="">
        <div class="container text-center text-md-start mt-5">
          <!-- Grid row -->
          <div class="row mt-3">
            <!-- Grid column -->
            <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
              <!-- Content -->
              <h6 class="text-uppercase fw-bold mb-4">
                <router-link to="/">
                  <img
                    src="/favicon.png"
                    class="d-inline-block align-middle"
                    width="55px"
                    alt="Kitten"
                  />Happy House</router-link
                >
              </h6>
              <p>친구들과 지낼 최고의 장소를</p>
              <p>함께 찾아보세요!!</p>
              <p>Find your best place</p>
              <p>to spend time with your friends!!</p>
            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
              <!-- Links -->
              <h6 class="text-uppercase fw-bold mb-4">Products</h6>
              <p>
                <a href="#!" class="text-reset">Angular</a>
              </p>
              <p>
                <a href="#!" class="text-reset">React</a>
              </p>
              <p>
                <a href="#!" class="text-reset">Vue</a>
              </p>
              <p>
                <a href="#!" class="text-reset">Laravel</a>
              </p>
            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
              <!-- Links -->
              <h6 class="text-uppercase fw-bold mb-4">Useful links</h6>
              <p>
                <a href="#!" class="text-reset">Pricing</a>
              </p>
              <p>
                <a href="#!" class="text-reset">Settings</a>
              </p>
              <p>
                <a href="#!" class="text-reset">Orders</a>
              </p>
              <p>
                <a href="#!" class="text-reset">Help</a>
              </p>
            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
              <!-- Links -->
              <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
              <p><i class="fas fa-home me-3"></i> New York, NY 10012, US</p>
              <p>
                <i class="fas fa-envelope me-3"></i>
                info@example.com
              </p>
              <p><i class="fas fa-phone me-3"></i> + 01 234 567 88</p>
              <p><i class="fas fa-print me-3"></i> + 01 234 567 89</p>
            </div>
            <!-- Grid column -->
          </div>
          <!-- Grid row -->
        </div>
      </section>
      <!-- Section: Links  -->

      <!-- Copyright -->
      <div
        class="text-center p-4"
        style="background-color: rgba(0, 0, 0, 0.05)"
      >
        © 2021 Copyright:
        <a class="text-reset fw-bold" href="https://ssafy.com/">SSAFY HOME</a>
      </div>
      <!-- Copyright -->
    </footer>
  </div>
  <!-- Footer -->
</template>

<script></script>

<style>
footer {
  position: relative;
  bottom: 0;
  left: 0;
  right: 0;
  color: white;
  background-color: #333333;
}
</style>
